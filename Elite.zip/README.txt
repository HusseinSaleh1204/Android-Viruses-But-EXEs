Elite.exe

This virus will delete your system files

The NON safety version will harm your computer

OS: XP, 7, 8, 8.1, 10, 11

Requirements: Net Framework 4

Created by: Me